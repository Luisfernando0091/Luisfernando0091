<?php
// redirecionar ala vista login
header ('location: vistas/login.html');
 ?>
