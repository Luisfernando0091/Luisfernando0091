

    <footer class="main-footer">

        <strong><a href="">solcuciones s.a.c.</a>. <span>Version 3.0</span></strong>
    </footer>
     <!-- jQuery -->
    <script src="../public/js/jquery-3.1.1.min.js"></script> 
    <!-- Bootstrap 3.3.5 -->
    <script type="text/javascript" src="../public/js/bootstrap.min.js"></script>
    <!-- AdminLTE App -->
    <script type="text/javascript" src="../public/js/app.min.js"></script>

    <!-- data Tables -->
    <script type="text/javascript" src="../public/datatables/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="../public/datatables/dataTables.buttons.min.js"></script>
    <script type="text/javascript" src="../public/datatables/buttons.html5.min.js"></script>
    <script type="text/javascript" src="../public/datatables/buttons.colVis.min.js"></script>

<script  type="text/javascript" src="../public/datatables/jszip.min.js"></script>
<script  type="text/javascript" src="../public/datatables/pdfmake.min.js"></script>
<script  type="text/javascript" src="../public/datatables/vfs_fonts.js"></script>


  <!-- sweetalert2 -->
 <script src="../public/js/sweetalert.min.js"></script>

 <!-- select -->
<script src="../public/js/bootstrap-select.min.js"></script>


 <!--calendar datepicker-->
        <script src="../public/js/jquery-ui.js"></script>
        

 </body>
</html>
